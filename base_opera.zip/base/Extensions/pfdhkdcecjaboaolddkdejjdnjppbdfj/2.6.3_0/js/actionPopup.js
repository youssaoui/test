$('#exception').html(chrome.i18n.getMessage("actionPopup_exception") + $('#exception').html());
$('#enter_in').html(chrome.i18n.getMessage("actionPopup_enter_in") + $('#enter_in').html());
$('#enter_in2').html(chrome.i18n.getMessage("actionPopup_enter_in2") + $('#enter_in2').html());
$('#addBlackList').html(chrome.i18n.getMessage("actionPopup_black_list") + $('#addBlackList').html());
$('#addWhiteList').html(chrome.i18n.getMessage("actionPopup_white_list") + $('#addWhiteList').html());
$('#addBlackListdomen').html(chrome.i18n.getMessage("actionPopup_black_listdomen") + $('#addBlackListdomen').html());
$('#addWhiteListdomen').html(chrome.i18n.getMessage("actionPopup_white_listdomen") + $('#addWhiteListdomen').html());
$('#status-plugin').html(chrome.i18n.getMessage("actionPopup_enable") + $('#status-plugin').html());
$('#enable_plugin').html(chrome.i18n.getMessage("actionPopup_enable_plugin") + $('#enable_plugin').html());
$('#disable_10_min').html(chrome.i18n.getMessage("actionPopup_disable_10_min") + $('#disable_10_min').html());
$('#disable_30_min').html(chrome.i18n.getMessage("actionPopup_disable_30_min") + $('#disable_30_min').html());
$('#disable_60_min').html(chrome.i18n.getMessage("actionPopup_disable_60_min") + $('#disable_60_min').html());
$('#disable_720_min').html(chrome.i18n.getMessage("actionPopup_disable_720_min") + $('#disable_720_min').html());
$('#locked_request').html(chrome.i18n.getMessage("actionPopup_locked_request") + $('#locked_request').html());
$('#text29').html(Localization('optionsPage.text29') + $('#text29').html());
$('#text32').html(Localization('optionsPage.text32') + $('#text32').html());
$('#text1').html(Localization('passwordPage.text1') + $('#text1').html());
$('#submit').html(Localization('passwordPage.text4') + $('#submit').html());
document.getElementById('input-pwd1').setAttribute('placeholder', Localization('passwordPage.text2'));
document.getElementById('input-pwd2').setAttribute('placeholder', Localization('passwordPage.text3'));

//if(LIBRARY.load('disablePluginStatus') === 'true') {
//	var disableData = JSON.parse(LIBRARY.load('disablePluginData'));
//	var disableSaveLastId = LIBRARY.load('disablePluginLastId');
	
//	for(var i=0; i < disableData.length; i++) {
//		var disableTime = disableData[i]['disable_time'];
//		var disableId = disableData[i]['id'];
//	}
//}else 
if(LIBRARY.load('password')) {
$('#main-block').show();
}else {
$('#lock').show();
$('#main-block').show();

$('#lock').bind('click', function() {
$('#password-block').show();
$('#main-block').hide();
})


}

//PASSWORD PAGE
$('#submit').bind('click', function() {
	var validate = true;
	var pwd1 = $('#input-pwd1').val();
	var pwd2 = $('#input-pwd2').val();
	
	if(pwd1 && (pwd1 == pwd2)) {
		LIBRARY.save('password', window.btoa(unescape(encodeURIComponent(pwd1+LIBRARY.load('UID')))));
	}else {
		validate = false;
		alert(Localization('passwordPage.alert'));
	}
	
	if(validate) {
		$('#password-block').hide();
		$('#lock').hide();
		$('#main-block').show();
	}
	
	return false;
});

var tabId = '', tabUrl = '', tabTitle = '';
var domain, urlblack, passCallback;
var status = 1;

var statusLog = {
	1: Localization('actionPopup.js.log1'),
	2: '<span class="text-danger">' + Localization('actionPopup.js.log2') + '<span>',
	3: '<span class="text-danger">' + Localization('actionPopup.js.log3') + '<span>',
	4: '<span class="text-success">' + Localization('actionPopup.js.log4') + '<span>',
	5: '<span class="text-danger">' + Localization('actionPopup.js.log5') + '<span>'
}

chrome.tabs.query({"active": true, "currentWindow": true}, function(Url) {
tabUrl=Url[0].url;
tabId = Url[0].id;
tabTitle = Url[0].title;
  var pageBlock = /domain-block=/.test(tabUrl) ? true : false;
	if(pageBlock) {
		urlblack = UTILS.fromBase64(decodeURIComponent(getURLParameter(tabUrl, 'domain-block')));
		status = getURLParameter(tabUrl, 'domain-status');
		domain = UTILS.urlDomain(urlblack);
		hostname = UTILS.Dom(urlblack);
		$('#site-insert').text(domain);
	}else if (tabTitle == 'Content filter'){
		domain = UTILS.urlDomain(tabUrl);
		hostname = UTILS.Dom(tabUrl);
		status = 5;
	} else {
		domain = UTILS.urlDomain(tabUrl);
		hostname = UTILS.Dom(tabUrl);
	}

	if(UTILS.checkWhiteList(domain)) {
		status = 4;
	}
	if(UTILS.checkBlackList(domain)) {
		status = 3;
	}
	$('#site-insert').text(domain);
	$('#status-insert').html(statusLog[status]);
});

checkDisablePlugin();

$('#addBlackList').bind('click', function() {
	passCallback = function() {
		UTILS.removeWhiteList(domain);
		UTILS.addBlackList(domain);
		chrome.tabs.reload(tabId);
		setTimeout(function() {
			window.location.reload();
		}, 1000);
	};
});

$('#addBlackListdomen').bind('click', function() {
	passCallback = function() {
		UTILS.removeWhiteListsayt(hostname);
		UTILS.removeBlackListsayt(hostname);
		UTILS.addBlackList(hostname);
		chrome.tabs.reload(tabId);
		setTimeout(function() {
			window.location.reload();
		}, 1000);
	};
});

$('#addWhiteList').bind('click', function() {
	passCallback = function() {
		UTILS.removeBlackList(domain);
		UTILS.addWhiteList(domain);
		window.location.reload();
		chrome.tabs.update(tabId, {url: domain});
		setTimeout(function() {
			window.location.reload();
		}, 1000);
	};
})

$('#addWhiteListdomen').bind('click', function() {
	passCallback = function() {
		UTILS.removeBlackList(hostname);
		UTILS.addWhiteList(hostname);
		window.location.reload();
		chrome.tabs.update(tabId, {url: hostname});
		setTimeout(function() {
			window.location.reload();
		}, 1000);
	}
});

$(".control a:eq(0)").click(function(){
	//passCallback = function() {
		UTILS.setTimeDisable(-10);
		LIBRARY.msgBackground({action:'iconStatus'}, function(data){});
		UTILS.reloadAllTabs();
		setTimeout(function() {
			window.location.reload();
		}, 200);
	//};
}); 

$(".control a:eq(1)").click(function(){
	passCallback = function() {
		UTILS.setTimeDisable(600);
		LIBRARY.msgBackground({action:'iconStatus'}, function(data){ });
		setTimeout(function() {
			window.location.reload();
		}, 200);
	};
});

$(".control a:eq(2)").click(function(){
	passCallback = function() {
		UTILS.setTimeDisable(1800);
		LIBRARY.msgBackground({action:'iconStatus'}, function(data){ });
		setTimeout(function() {
			window.location.reload();
		}, 200);
	};
}); 

$(".control a:eq(3)").click(function(){
	passCallback = function() {
		UTILS.setTimeDisable(3600);
		LIBRARY.msgBackground({action:'iconStatus'}, function(data){});
		setTimeout(function() {
			window.location.reload();
		}, 200);
	};
});

$(".control a:eq(4)").click(function(){
	passCallback = function() {
		UTILS.setTimeDisable(43200);
		LIBRARY.msgBackground({action:'iconStatus'}, function(data){});
		setTimeout(function() {
			window.location.reload();
		}, 200);
	};
});


$("#options-panel").bind('click', function() {
chrome.tabs.create({ url: chrome.extension.getURL("html/options.html") });
});

$(".control a:eq(1), .control a:eq(2), .control a:eq(3), .control a:eq(4), #addBlackList, #addWhiteList, #addBlackListdomen, #addWhiteListdomen").click(function(){
	
if (LIBRARY.load('password')){
	$('#input-pass').val('');
	$('#modal').modal('show');
} else {
	var pass = '';
	checkPassword(pass, passCallback);
}
});

$("#pwd-submit").bind('click', function() {
	var pass = $('#input-pass').val();
	checkPassword(pass, passCallback);
});

function checkDisablePlugin() {
	if(UTILS.checkTimeDisable()) {
		var disTime = UTILS.getTimeDisable()*1;
		var now = new Date().getTime();
		var min = Math.round((disTime - now) / (1000 * 60));

		$(".eye i").removeClass("").addClass("glyphicon-off red");
		$('#status-plugin').text(Localization('actionPopup.js.log6') + ' ' + min + Localization('actionPopup.js.log7'));
	} else {
$(".eye i").removeClass("").addClass("glyphicon-off green");
	}
}

function getURLParameter(url, name) {
    return decodeURI(
        (RegExp(name + '=' + '(.+?)(&|$)').exec(url)||[,null])[1]
    );
}

function Localization(key) {
	var newKey = key.replace(/\./img, '_');
	return chrome.i18n.getMessage(newKey);
}

function checkPassword(pass, callback) {

	if((!LIBRARY.load('password')) || LIBRARY.load('password') === window.btoa(unescape(encodeURIComponent(pass+LIBRARY.load('UID'))))) {
		if(callback) {
			callback();
		}
	} else {
		alert(Localization('actionPopup.js.log8'));
	}
}

$(document).ready(function() {
$("html").contextmenu(function(){ 
return false; 
});
});