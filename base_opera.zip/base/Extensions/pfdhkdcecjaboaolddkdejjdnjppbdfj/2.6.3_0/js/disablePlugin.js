var disablePluginBackground = {
	activeCloseTab: false,
	checkActiveCloseTab: function() {
		var _this = this;
		setTimeout(function() {
			var isActiveTab = false;
			chrome.windows.getAll(null, function(wins) {
			  for (var j = 0; j < wins.length; ++j) {
			chrome.tabs.query({}, function(tabs) {
				var count = tabs.length;
				for (var i = 0; i < count; ++i) {
if(LIBRARY.load('password') && LIBRARY.load('onoff')=='true'){
chrome.tabs.query({"active": true, "currentWindow": true}, function(tab) {
	if (tab[0].url.indexOf("chrome://extensions/")+1 && !UTILS.checkTimeDisable() || 
	    tab[0].url.indexOf("chrome://startpage/extensions")+1 && !UTILS.checkTimeDisable() || 
		tab[0].url.indexOf("chrome://settings/")+1 && !UTILS.checkTimeDisable() || 
		tab[0].url.indexOf("about:addons")+1 && !UTILS.checkTimeDisable() || 	
		tab[0].url.indexOf("about:preferences")+1 && !UTILS.checkTimeDisable() || 		
		tab[0].url.indexOf("chrome://tune/")+1 && !UTILS.checkTimeDisable() ||
		tab[0].url.indexOf("edge://extensions/")+1 && !UTILS.checkTimeDisable() ||
		tab[0].url.indexOf("edge://settings/")+1 && !UTILS.checkTimeDisable())
	{
document.getElementsByTagName("body")[0].style.display = "none";
chrome.tabs.update({url: "http://lidrekon.ru/block/block.php"});
	}
 });
}
					if ((tabs[i].url.indexOf("http://") >= 0 || tabs[i].url.indexOf("https://") >= 0)) {
						if(!_this.activeCloseTab) {
							_this.activeCloseTab = tabs[i].id;
							
						}
						
						if(_this.activeCloseTab == tabs[i].id) {
							isActiveTab = true;
						}
					}
					
					if(i == count-1) {
						if(isActiveTab) {
							LIBRARY.msgContent(_this.activeCloseTab, {'action': 'activeCloseTab', 'data': {'uid': UID, 'counttabs': count}});
						}else {
							_this.activeCloseTab = false;
						}
					}
					
				}
				});
			  }
				_this.checkActiveCloseTab();
			});
		}, 1200);
	}
}
var disablePluginContent = {
	disablePlugin: false,
	countTabs: 0,
	checkStatePlugin: function(data) {
		this.disablePlugin = true;
		_this = this;
		setTimeout(function() {
			try {
				var manifest = chrome.runtime.getManifest();
				var state = manifest.version + '';
				if(state == 'undefined') {
					
				}else {
					_this.checkStatePlugin(data);
				}
			}catch(err) {

			}

		}, 1000, data);
	},
	event: function () {
		_this = this;
		LIBRARY.onMessage(function(data) {
			if(data['action'] === 'activeCloseTab') {
				_this.countTabs = data['data']['counttabs'];
				if(!_this.disablePlugin) {
					_this.checkStatePlugin(data['data']);
				}
			}
		});
	} 
}