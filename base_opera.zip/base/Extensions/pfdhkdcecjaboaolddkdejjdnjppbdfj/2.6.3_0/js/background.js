var tabs = {};
//OPEN NEW TAB WITH SITE IF IT IS FIRST RUN	
if(!UTILS.checkUserID()) {
	//LIBRARY.ajax({url: 'https://lidrekon.ru/block/checkopentab.php', success: function(data) { 
	//	if(data === 'true') {
	//		chrome.tabs.create({ url: 'https://lidrekon.ru/block/' });
	//	}
	// }});
	 
	 //LOAD CONFIG FROM LOCAL FILE
	//var config = LIBRARY.ajax({url: '../config/main.json', success: function(data) { config = JSON.parse(data); LIBRARY.save('config', data);}});
 }
 
//GET USER ID
var UID = UTILS.getUserID();

//GET VERSION EXTENSIONS
//var ver = UTILS.getVer();

//LOAD CONFIG FROM LOCALSTORAGE
config = JSON.parse(LIBRARY.load('config'));

UTILS.configUpdater('https://lidrekon.ru/update.json', function(loadConfig) {
	config = loadConfig;
});

//ICON ALERT IF NO PASSWORD
UTILS.iconFlashForPasswd();

//CHECK STATUS ICON
UTILS.iconDisable();

//RELOAD ALL TABS
UTILS.reloadAllTabs();

//INIT CHECK DISABLING PLUGIN
disablePluginBackground.checkActiveCloseTab();

//ROUTER
LIBRARY.onMessage(function(request, sender, sendResponse) {
//if(request.action === 'pingServer') {
//LIBRARY.ajax({url: 'https://lidrekon.ru/block/checkopentab.php', success: function(data) {
//LIBRARY.msgContent(sender.tab.id, {'action': 'pingServer', 'data': data});
//}, error: function() {
//LIBRARY.msgContent(sender.tab.id, false);
//}});
//}

if(request.action === 'getConfig') {sendResponse(config);}

if(request.action === 'checkWhiteList') {sendResponse(UTILS.checkWhiteList(request.url));}

if(request.action === 'checkBlackList') {sendResponse(UTILS.checkBlackList(request.url));}

if(request.action === 'getkeyword') {sendResponse(UTILS.getkeyword(request.url));}

if(request.action == 'checkOffPlugin') {sendResponse(UTILS.checkTimeDisable());}

if(request.action == 'badRequest') {sendResponse(UTILS.checkTimeDisable());}
	
if(request.action == 'getPassword') {sendResponse(LIBRARY.load('password'));}
	
if(request.action == 'addWhiteList') {
UTILS.removeBlackList(request.url);
sendResponse(UTILS.addWhiteList(request.url));
}
	
if(request.action == 'openOptions') {chrome.tabs.create({ url: chrome.runtime.getURL("html/options.html") });}
	
if(request.action == 'getUID') {sendResponse(UID);}

if(request.action == 'iconStatus') {UTILS.iconDisable();}
	
if(request.action == 'sentRequest') {
LIBRARY.ajax({url: request.url, success: function(data) {
if(request.success)
request.success(data);
}, error: function() {
if(request.error)
request.error(data);
}});
}

//11111111111	
if(request.action == 'geturlwhitelist') {sendResponse(LIBRARY.load('urlwhitelist'));};
if(request.action == 'getdomainwhitelist') {sendResponse(LIBRARY.load('domainwhitelist'));};
if(request.action == 'geturlblacklist') {sendResponse(LIBRARY.load('urlblacklist'));};
if(request.action == 'getdomainblacklist') {sendResponse(LIBRARY.load('domainblacklist'));};
if(request.action == 'getkeywords') {sendResponse(LIBRARY.load('keywords'));};
if(request.action == 'getmoywhitelist') {sendResponse(LIBRARY.load('moywhitelist'));};
if(request.action == 'getmoyblacklist') {sendResponse(LIBRARY.load('moyblacklist'));};
if(request.action == 'getmoykeyword') {sendResponse(LIBRARY.load('moykeyword'));};
if(request.action == 'onoff') {sendResponse(LIBRARY.load('onoff'));};
if(request.action == 'getblockall') {sendResponse(LIBRARY.load('blockall'));};
//11111111111111111	
});