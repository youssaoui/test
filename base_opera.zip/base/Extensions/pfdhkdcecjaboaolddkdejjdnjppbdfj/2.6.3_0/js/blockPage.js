$('#text1').html(Localization('blockPage.text1') + $('#text1').html());
$('#text2').html(Localization('blockPage.text2') + $('#text2').html());
$('#text3').html(Localization('blockPage.text3') + $('#text3').html());
$('#text4').html(Localization('blockPage.text4') + $('#text4').html());
$('#addWhiteList').html(Localization('blockPage.text5') + $('#addWhiteList').html());
$('#addWhiteListdomen').html(Localization('blockPage.text7') + $('#addWhiteListdomen').html());
$('#backButton').html(Localization('blockPage.text6') + $('#backButton').html());

var url = document.location.href;
var urlblack = UTILS.fromBase64(decodeURIComponent(UTILS.getURLParameter(url, 'domain-block')));
var status = UTILS.getURLParameter(url, 'domain-status');
var urlblackProtocol = urlblack.indexOf('https') == 0 ? 'https' : 'http';
var domain = UTILS.urlDomain(urlblack);
var hostname = UTILS.Dom(urlblack);

var path = chrome.runtime.getURL('html/block.html?domain-block=' + encodeURIComponent(UTILS.toBase64(urlblack)) + '&domain-status=' + status);

$('#site-insert').text(domain);

chrome.history.deleteUrl({url: path});

$("#addWhiteList").click(function(e){
if (LIBRARY.load('password')==''){alert('1');
	UTILS.removeBlackList(domain);
	UTILS.addWhiteList(domain);
	setTimeout(function() {
				window.location.replace(urlblack);
			}, 700);
} else {	
	$('#input-pass').val('');
	$('#modal').modal('show');
}
});

$("#addWhiteListdomen").click(function(e){
if (LIBRARY.load('password')==''){
	UTILS.removeBlackList(hostname);
	UTILS.addWhiteList(hostname);
	setTimeout(function() {
				window.location.replace(urlblack);
			}, 700);
} else {	
	$('#input-pass').val('');
	$('#modal').modal('show');
}
});

$("#pwd-submit").bind('click', function() {
	var pass = $('#input-pass').val();
	checkPassword(pass, passCallback);
})


$('#addWhiteList').bind('click', function() {
	passCallback = function() {
		UTILS.removeBlackList(domain);
		UTILS.addWhiteList(domain);
		setTimeout(function() {
				window.location.replace(urlblack);
			}, 700);
	}
});

$('#addWhiteListdomen').bind('click', function() {
	passCallback = function() {
		UTILS.removeBlackList(hostname);
		UTILS.addWhiteList(hostname);
		setTimeout(function() {
				window.location.replace(urlblack);
			}, 700);
	}
});

$("#options-panel").bind('click', function() {
chrome.tabs.create({ url: chrome.runtime.getURL("html/options.html") });
});

function checkPassword(pass, callback) {
	if((LIBRARY.load('password') === window.btoa(unescape(encodeURIComponent(pass+LIBRARY.load('UID'))))) || (LIBRARY.load('password') ===pass)) {
		if(callback) {
			callback();
		}
	} else {
		alert(Localization('actionPopup.js.log8'));
	}
}

function Localization(key) {
	var newKey = key.replace(/\./img, '_');

	return chrome.i18n.getMessage(newKey);
}


if(history.length > 1) {	
	$('.back-button').show();
	
	$('#backButton').bind('click', function(e) {
		e.preventDefault();
		
		history.back();
	});
}

$(document).ready(function() {
$("html").contextmenu(function(){ 
return false; 
});
});