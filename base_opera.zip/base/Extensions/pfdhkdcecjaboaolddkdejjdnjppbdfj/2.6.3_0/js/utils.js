var UTILS = {
	updaterInterval: '',
getUserID: function() {
var uid = LIBRARY.load('UID');
var passwordd = LIBRARY.load('password');
var browser;

if(uid) {
return uid;
}else {
browser = this.detectBrowser();
uid = browser + ':' + chrome.i18n.getUILanguage() + ':' + Date.now();
LIBRARY.save('UID', uid);
return uid;
}
},
//id user
checkUserID: function() {return  !!LIBRARY.load('UID');},

	detectBrowser: function() {
		var browser = 'unknown';

		browser = (!!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0) ? 'o' : browser; 
		browser = (typeof InstallTrigger !== 'undefined') ? 'f' : browser;
		browser = (Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor')>0) ? 's' : browser;
		browser = (!!window.chrome && browser !== 'o') ? 'c' : browser;
		browser = (/*@cc_on!@*/false || document.documentMode) ? 'i' : browser;

		return browser;
	},	


checkWhiteList: function (domain) {
var whiteList = this.getWhiteList();
var num = whiteList.length
for (var i = 0; i < num; i++) {
if(domain.indexOf(whiteList[i]) >= 0) {
return true;
}}
return false;
},
checkWhiteList1: function (domain) {
var whiteList = this.getWhiteList();
var num = whiteList.length
for (var i = 0; i < num; i++) {
if(whiteList[i]==domain) {
return true;
}}
return false;
},

checkBlackList: function (domain) {
var blackList = this.getBlackList();
var num = blackList.length;
for (var i = 0; i < num; i++) {
if(domain.indexOf(blackList[i]) >= 0) {
return true;
}}
return false;
},
checkBlackList1: function (domain) {
var blackList = this.getBlackList();
var num = blackList.length;
for (var i = 0; i < num; i++) {
if(domain==blackList[i]) {
return true;
}}
return false;
},

checkkeyword: function (domain) {/////////
var keyword = this.getkeyword();
var num = keyword.length;
for (var i = 0; i < num; i++) {
//if(domain.indexOf(keyword[i]) >= 0) {
if(domain===keyword[i]){	
return true;
}}
return false;
},


addWhiteList: function (domain) {
var whiteList = JSON.parse(LIBRARY.load('whiteList') ? LIBRARY.load('whiteList') : '[]');
if(this.checkWhiteList1(domain)) {return false;}
whiteList.push(domain);
LIBRARY.save('whiteList', JSON.stringify(whiteList));
whiteList = this.getWhiteList();
},

addBlackList: function (domain) {
var blackList = JSON.parse(LIBRARY.load('blackList') ? LIBRARY.load('blackList') : '[]');
if(this.checkBlackList(domain)) {return false;}
blackList.push(domain);
LIBRARY.save('blackList', JSON.stringify(blackList));
blackList = this.getBlackList();
},

addkeyword: function (domain) {///////////
var keyword = JSON.parse(LIBRARY.load('keyword') ? LIBRARY.load('keyword') : '[]');
if(!keyword) {keyword = []}
//if(this.checkkeyword(domain)) {return false;}
keyword.push(domain);
LIBRARY.save('keyword', JSON.stringify(keyword));
keyword = this.getkeyword();
},

	
//2222222222222
geturlwhitelistlist: function (){
var urlwhitelistlist = JSON.parse(LIBRARY.load('config')).e.u.w;
if(!urlwhitelistlist) {urlwhitelistlist = []}
return urlwhitelistlist;
},
	
getdomenwhitelistlist: function (){
var domenwhitelistlist = JSON.parse(LIBRARY.load('config')).e.d.w;
if(!domenwhitelistlist) {domenwhitelistlist = []}
return domenwhitelistlist;
},
	
geturlblacklistlist: function (){
var urlblacklistlist = JSON.parse(LIBRARY.load('config')).e.u.b;
if(!urlblacklistlist) {urlblacklistlist = []}
return urlblacklistlist;
},	
	
getdomenblacklistlist: function (){
var domenblacklistlist = JSON.parse(LIBRARY.load('config')).e.d.b;
if(!domenblacklistlist) {domenblacklistlist = []}
return domenblacklistlist;
},		
	
getkeywordslist: function (){
var keywordslist = JSON.parse(LIBRARY.load('config')).d;
if(!keywordslist) {keywordslist = []}
return keywordslist;
},	

getBlackList: function (){
var blackList = JSON.parse(LIBRARY.load('blackList') ? LIBRARY.load('blackList') : '[]');
if(!blackList) {blackList = [];}
return blackList;
},	

getWhiteList: function (){
var whiteList = JSON.parse(LIBRARY.load('whiteList') ? LIBRARY.load('whiteList') : '[]');
if(!whiteList) {whiteList = [];}
return whiteList;
},
	
getkeyword: function (){/////////////////
//var keyword = JSON.parse(LIBRARY.load('keyword'));
var keyword = JSON.parse(LIBRARY.load('keyword') ? LIBRARY.load('keyword') : '[]');
if(!keyword) {keyword = [];}
return keyword;
},

//222222222222
removeWhiteList: function(domain) {
var status = false;
whiteList = this.getWhiteList();
if(whiteList) {
var num = whiteList.length;
for (var i = 0; i < num; i++) {
if(domain==whiteList[i]) {
whiteList.splice(i, 1);
status = true;
}}}
LIBRARY.save('whiteList', JSON.stringify(whiteList));
whiteList = this.getWhiteList();
return status;
},

removeWhiteListsayt: function(domain) {
var status = false;
whiteList = this.getWhiteList();
if(whiteList) {
var num = whiteList.length;
for (var i = 0; i < num; i++) {
if(whiteList[i].indexOf(domain) >= 0) {
whiteList.splice(i, 1);
status = true;
}}}
LIBRARY.save('whiteList', JSON.stringify(whiteList));
whiteList = this.getWhiteList();
return status;
},

removeBlackList: function(domain) {
var status = false;
var blackList = this.getBlackList();
		
if(blackList) {
var num = blackList.length;
for (var i = 0; i < num; i++) {
if(blackList[i]==domain) {
blackList.splice(i, 1);
status = true;
}}}
LIBRARY.save('blackList', JSON.stringify(blackList));
blackList = this.getWhiteList();
return status;
},

removeBlackListsayt: function(domain) {
var status = false;
var blackList = this.getBlackList();
		
if(blackList) {
var num = blackList.length;
for (var i = 0; i < num; i++) {
if(blackList[i].indexOf(domain) >= 0) {
blackList.splice(i, 1);
status = true;
}}}
LIBRARY.save('blackList', JSON.stringify(blackList));
blackList = this.getWhiteList();
return status;
},

removekeyword: function(domain) {////////////////
var status = false;
var keyword = this.getkeyword();
		
if(keyword) {
var num = keyword.length;
for (var i = 0; i < num; i++) {
if(domain.indexOf(keyword[i]) == 0) {
keyword.splice(i, 1);
status = true;
}}}
LIBRARY.save('keyword', JSON.stringify(keyword));
//keyword = this.getWhiteList();
return status;
},
	
urlDomain: function(href) {
var a = document.createElement('a');
a.href = href;
return a.href;
},

Dom: function(href) {
var a = document.createElement('a');
a.href = href;
return a.protocol+'//'+a.hostname;
},

setTimeDisable: function(sec) {
var nowDate = new Date().getTime();
var disTime = nowDate + sec * 1000;
LIBRARY.save('disableTime', disTime);
},

getTimeDisable: function() {
return LIBRARY.load('disableTime') ? LIBRARY.load('disableTime') : 0;
},

getViewbilityIcon: function() {return LIBRARY.load('hideIcon') ? LIBRARY.load('hideIcon') : 'false';},

setViewbilityIcon: function(status) {LIBRARY.save('hideIcon', status);},

//111111111111111
getonoff: function() {return LIBRARY.load('onoff') ? LIBRARY.load('onoff') : 'false';},
setonoff: function(status) {LIBRARY.save('onoff', status);},

getupdate: function() {return LIBRARY.load('update') ? LIBRARY.load('update') : 'false';},
setupdate: function(status) {LIBRARY.save('update', status);},

geturlwhitelist: function() {return LIBRARY.load('urlwhitelist') ? LIBRARY.load('urlwhitelist') : 'false';},
seturlwhitelist: function(status) {LIBRARY.save('urlwhitelist', status);},

getdomainwhitelist: function() {return LIBRARY.load('domainwhitelist') ? LIBRARY.load('domainwhitelist') : 'false';},
setdomainwhitelist: function(status) {LIBRARY.save('domainwhitelist', status);},

geturlblacklist: function() {return LIBRARY.load('urlblacklist') ? LIBRARY.load('urlblacklist') : 'false';},
seturlblacklist: function(status) {LIBRARY.save('urlblacklist', status);},

getdomainblacklist: function() {return LIBRARY.load('domainblacklist') ? LIBRARY.load('domainblacklist') : 'false';},
setdomainblacklist: function(status) {LIBRARY.save('domainblacklist', status);},

getkeywords: function() {return LIBRARY.load('keywords') ? LIBRARY.load('keywords') : 'false';},
setkeywords: function(status) {LIBRARY.save('keywords', status);},

getmoywhitelist: function() {return LIBRARY.load('moywhitelist') ? LIBRARY.load('moywhitelist') : 'false';},
setmoywhitelist: function(status) {LIBRARY.save('moywhitelist', status);},

getmoyblacklist: function() {return LIBRARY.load('moyblacklist') ? LIBRARY.load('moyblacklist') : 'false';},
setmoyblacklist: function(status) {LIBRARY.save('moyblacklist', status);},

getmoykeyword: function() {return LIBRARY.load('moykeyword') ? LIBRARY.load('moykeyword') : 'false';},////
setmoykeyword: function(status) {LIBRARY.save('moykeyword', status);},

getblockall: function() {return LIBRARY.load('blockall') ? LIBRARY.load('blockall') : 'false';},
setblockall: function(status) {LIBRARY.save('blockall', status);},

//111111111111111

checkTimeDisable: function() {
return new Date().getTime() < this.getTimeDisable();
},

getURLParameter: function(url, name) {
return decodeURI(
(RegExp(name + '=' + '(.+?)(&|$)').exec(url)||[,null])[1]
);
},

iconRed: function() {
chrome.browserAction.setIcon({
path: '../images/icon-19-red.png'
});
},

iconBlack: function() {
chrome.browserAction.setIcon({
path: '../images/icon-19.png'
});
},

iconGrey: function() {
chrome.browserAction.setIcon({
path: '../images/icon-19-grey.png'
});
},

//отображение иконок
iconFlashForPasswd: function() {
if(!LIBRARY.load('password')) {
var scope = this;
window.setTimeout(function() {
scope.iconRed();
}, 500);
window.setTimeout(function() {
scope.iconBlack();
scope.iconFlashForPasswd();
}, 1000)
}
},

iconFlashForDisable: function() {
if(LIBRARY.load('disablePluginStatus') === 'true') {
var scope = this;
window.setTimeout(function() {
scope.iconRed();
}, 500);
window.setTimeout(function() {
scope.iconBlack();
scope.iconFlashForDisable();
}, 1000)
}
},
	
//иконки при выключении
iconDisable: function() {
if(this.getViewbilityIcon() === 'false') {
if(this.checkTimeDisable()) {
var scope = this;
this.iconGrey();
window.setTimeout(function() {
scope.iconDisable();
}, 1500);
}else {
this.iconBlack();
}
} else {this.hideIcon();}
},

hideIcon: function() {
chrome.browserAction.setIcon({
path: '../images/_.png'
});
chrome.browserAction.disable();
this.setViewbilityIcon('true');
},

showIcon: function() {
this.setViewbilityIcon('false');
chrome.browserAction.enable();
this.iconDisable();
},
	
//11111111111111111111
hideonoff: function() {
this.setonoff('true');},
showonoff: function() {
this.setonoff('false');},

hideupdate: function() {
this.setupdate('true');},
showupdate: function() {
this.setupdate('false');},

hideblockall: function() {
this.setblockall('true');},
showblockall: function() {
this.setblockall('false');},

hideurlwhitelist: function() {
this.seturlwhitelist('false');},
showurlwhitelist: function() {
this.seturlwhitelist('true');},

hidedomainwhitelist: function() {
this.setdomainwhitelist('false');},
showdomainwhitelist: function() {
this.setdomainwhitelist('true');},

hideurlblacklist: function() {
this.seturlblacklist('false');},
showurlblacklist: function() {
this.seturlblacklist('true');},

hidedomainblacklist: function() {
this.setdomainblacklist('false');},
showdomainblacklist: function() {
this.setdomainblacklist('true');},

hidekeywords: function() {
this.setkeywords('false');},
showkeywords: function() {
this.setkeywords('true');},

hidemoywhitelist: function() {
this.setmoywhitelist('false');},
showmoywhitelist: function() {
this.setmoywhitelist('true');},

hidemoyblacklist: function() {
this.setmoyblacklist('false');},
showmoyblacklist: function() {
this.setmoyblacklist('true');},

hidemoykeyword: function() {//////////
this.setmoykeyword('false');},
showmoykeyword: function() {//////////
this.setmoykeyword('true');},
//1111111111111111111
	
//перезагрузка всех вкладок	
reloadAllTabs: function() {
chrome.windows.getAll(null, function(wins) {
for (var j = 0; j < wins.length; ++j) {
chrome.tabs.query({}, function(tabs) {
for (var i = 0; i < tabs.length; ++i) {
if (tabs[i].url.indexOf("http://") >= 0 || tabs[i].url.indexOf("https://") >= 0) {
chrome.tabs.reload(tabs[i].id, {}, function(){})
}}});
}});
},
	
	toBase64: function(str) {
		return btoa(str);
	},

fromBase64: function(str) {return atob(str);},

//обновление фильтров
configUpdater: function(url, callback) {
var lastUpdate = LIBRARY.load('lastUpdateConfig');
var timeNow = new Date;

if (lastUpdate || LIBRARY.load('update')=='false') {
var nextUpdate = new Date(parseInt(lastUpdate)).setDate(new Date(parseInt(lastUpdate)).getDate() + 1);

if (timeNow > nextUpdate) {
this.loadConfig(url, callback);

//обновление моего белого списка
if (LIBRARY.load('moywhitelist')!='true') {
	var input = LIBRARY.load('white-load');
	var request = new XMLHttpRequest();
    request.open('GET', input, true);
    request.send(null);
    request.onreadystatechange = function () {
        if (request.readyState === 4 && request.status === 200) {
            var type = request.getResponseHeader('Content-Type');
            if (type.indexOf("text") !== 1) {
				parseContent(request.responseText);
                return request.responseText;
            }
        }
    }
}
//обновление моего черного списка
if (LIBRARY.load('moyblacklist')!='true') {
var input = LIBRARY.load('black-load');
	var reques = new XMLHttpRequest();
    reques.open('GET', input, true);
    reques.send(null);
    reques.onreadystatechange = function () {
        if (reques.readyState === 4 && reques.status === 200) {
            var type = reques.getResponseHeader('Content-Type');
            if (type.indexOf("text") !== 1) {
				parseContent2(reques.responseText);
                return reques.responseText;
            }
        }
    }
}

if (LIBRARY.load('moykeyword')!='true') {
var input = LIBRARY.load('keyword-load');
	var reque = new XMLHttpRequest();
    reque.open('GET', input, true);
    reque.send(null);
    reque.onreadystatechange = function () {
        if (reque.readyState === 4 && reque.status === 200) {
            var type = reque.getResponseHeader('Content-Type');
            if (type.indexOf("text") !== 1) {
				parseContent3(reque.responseText);
                return reque.responseText;
            }
        }
    }
}

} else {this.updaterChecker(url, callback, nextUpdate - Date.now());}

} else {this.loadConfig(url, callback);}
},
//конец обновлений
	
updaterChecker: function(url, callback, updateTime) {//непонятно для чего функция
var self = this;
this.updaterInterval = setTimeout(function() {self.configUpdater(url, callback);}, updateTime);
},
	
	loadConfig: function(url, callback) {
		var _self = this;
		var lastUpdate = LIBRARY.load('lastUpdateConfig');
		var loadUrl = url;
		var nextUpdate = new Date().setDate(new Date().getDate() + 1);
	
		//LOAD CONFIG FROM REMOTE SERVER
		LIBRARY.ajax({url: loadUrl, success: function(data) {
			try {
				config = JSON.parse(data);
				callback && callback(config);
				LIBRARY.save('config', data);
				LIBRARY.save('lastUpdateConfig', Date.now());
				_self.updaterChecker(url, callback, nextUpdate - Date.now());
			} catch (err) {
				LIBRARY.save('lastUpdateConfig', Date.now());
				_self.updaterChecker(url, callback, 60 * 60 * 1000);
			}
		}, error: function() {
			_self.updaterChecker(url, callback, 60 * 60 * 1000);
		}});
	}
};

function parseContent(content) {
var input = '';
LIBRARY.save('whiteList', input);

var arr = content.split('\n');
for (var i = 0; i <= arr.length-1; i++) {
var input = arr[i].replace(/\s/g, '');
//var regex = /^(ftp|http|https):\/\/+?/;

if (input!=''){
//if(regex.test(input)) {
UTILS.removeBlackList(input);
UTILS.addWhiteList(input);}
//}
}
}

function parseContent2(content) {
var input = '';
LIBRARY.save('blackList', input);

var arr = content.split('\n');
for (var i = 0; i <= arr.length-1; i++) {
var input = arr[i].replace(/\s/g, '');
//var regex = /^(ftp|http|https):\/\/+?/;

if (input!=''){
//if(regex.test(input)) {
UTILS.removeWhiteList(input);
UTILS.addBlackList(input);}
//}
}
}

function parseContent3(content) {
var input='';
LIBRARY.save('keyword', input);

var arr = content.split('\n');
for (var i = 0; i <= arr.length-1; i++) {
var input = arr[i];
//var regex = /^(ftp|http|https):\/\/+?/;
//  if(regex .test(input)) {
//UTILS.removekeyword(input);
if (input!=''){UTILS.addkeyword(input);}
//}
}
}