var badWorld = '';
var url = location.href;
var domain = UTILS.urlDomain(url);
var links;
var outer=false, blocked=true;
var whiteList = LIBRARY.msgBackground({action:'checkWhiteList', url: domain}, function(data){ whiteList = data;});
var blackList = LIBRARY.msgBackground({action:'checkBlackList', url: domain}, function(data){ blackList = data;});

var offPlugin = LIBRARY.msgBackground({action:'checkOffPlugin'}, function(data){ offPlugin = data;});
var UID = LIBRARY.msgBackground({action:'getUID'}, function(data){ UID = data;});
//1111111111
var urlwhitelist = LIBRARY.msgBackground({action:'geturlwhitelist'}, function(data){ urlwhitelist = data;});
var domainwhitelist = LIBRARY.msgBackground({action:'getdomainwhitelist'}, function(data){ domainwhitelist = data;});
var urlblacklist = LIBRARY.msgBackground({action:'geturlblacklist'}, function(data){ urlblacklist = data;});
var domainblacklist = LIBRARY.msgBackground({action:'getdomainblacklist'}, function(data){ domainblacklist = data;});
var keywords = LIBRARY.msgBackground({action:'getkeywords'}, function(data){ keywords = data;});
var moywhitelist = LIBRARY.msgBackground({action:'getmoywhitelist'}, function(data){ moywhitelist = data;});
var moyblacklist = LIBRARY.msgBackground({action:'getmoyblacklist'}, function(data){ moyblacklist = data;});
var moykeyword = LIBRARY.msgBackground({action:'getmoykeyword'}, function(data){ moykeyword = data;});
var keyword = LIBRARY.msgBackground({action:'getkeyword'}, function(data){ keyword = data;});
var blockall = LIBRARY.msgBackground({action:'getblockall'}, function(data){ blockall = data;});
//1111111111

disablePluginContent.event();

var matchWorld = {
	test: function(text, encodeType) {
		var num = badWorld.length;
		for(var i = 0; i < num; i++) {
			var reg = new RegExp(badWorld[i], 'img');
			if(reg.test(text)) {
				return true;
			}
		}
	return false;
	},
	match: function(text) {
		var badStr = '';
		var num = badWorld.length;
		for(var i = 0; i < num; i++) {
			var reg = new RegExp('(^|\\s)'+badWorld[i]+'($|\\s)', 'img');
			var regStr = new RegExp('(.{0,40}' + badWorld[i] + '.{0,40})', 'img');
			if(reg.test(text)) {
				badStr += '<b>' + text.match(reg) + '</b>: ' + text.match(regStr) + '</br>';
				break;
			}
		}
	return badStr;
	}
}

var matchReg = {
	match: function(key, arr) {
		var num = arr.length;
		for(var i = 1; i < num; i++) {
			if(arr[i] === '') continue;
			var reg = new RegExp("^((http|https):\/\/(www.|))?"+arr[i]);
			
			if(reg.test(key)) {
				return {
					'key': key,
					'match': arr[i]
				}; 
			}
		}
	return false;
	}
};

function getContent(doc) {
if(!doc.body) return;
	var content = doc.body.textContent;
	content = content.replace(/{(.*?)}/img,' '); //delete function
	content = content.replace(/<.*?>/img,' '); // delete tag
	content = content.replace(/.\w+\s/img,' '); // delete CSS selector
	//content = content.replace(/#\S+\s/img,' ' ); // delete CSS id
	//content = content.replace(/\w+\.\w+/img,' ');
	content = content.replace(/\n/img,' ');
	content = content.replace(/\s+/g, ' '); // delete space
	content = content.toLowerCase();
return content;
}

function getTitle(doc) {
var titleEl = doc.getElementsByTagName('title')[0];
var title = titleEl ? titleEl.text.toLowerCase() : '';
return title;
}

function getMetaContent(doc, propName) {
var metas = doc.getElementsByTagName('meta');
	for (i = 0; i < metas.length; i++) {
		if (metas[i].getAttribute("name") == propName) {
			return metas[i].getAttribute("content");
		}
	}
	return '';
} 

LIBRARY.msgBackground({action:'getConfig'}, function(data){
if (offPlugin==true){
	window.addEventListener("DOMContentLoaded", () => {
	document.body.style.opacity = "100";
	});
}
if(offPlugin) return false;
if (offPlugin==false){
	document.addEventListener("DOMContentLoaded", () => {
	scanContentTabs(data);
});
window.onload = function() {
	var container = document.querySelector('body');
	let observer = new MutationObserver(function(){
		scanContentTabs(data);
	});
	observer.observe(container, {
		subtree: true,
		childList: true
	});
}
}});

function scanContentTabs(data) {
if(/lidrekon.ru/.test(url)) {document.body.style.opacity = "100";}else{

if (moykeyword!='true' && keywords!='false'){badWorld=keyword;}
if (keywords!='true' && moykeyword!='false'){badWorld=data.d;}
if (moykeyword!='true' && keywords!='true'){badWorld=keyword.concat(data.d);}

if (urlwhitelist!='true'){var exceptUrlWhiteList=data.e.u.w;}else{var exceptUrlWhiteList='[]';}
if (urlblacklist!='true'){var exceptUrlBlackList=data.e.u.b;}else{var exceptUrlBlackList='[]';}
if (domainwhitelist!='true'){var exceptDomainWhiteList=data.e.d.w;}else{var exceptDomainWhiteList='[]';}
if (domainblacklist!='true'){var exceptDomainBlackList=data.e.d.b;}else{var exceptDomainBlackList='[]';}	
var status;
var content = getContent(document);
var title = getTitle(document);
var pageDescription = getMetaContent(document, "description");
var pageKeywords = getMetaContent(document, "keywords");
var badWords='';

if (links==location.href){

} else {

if (matchReg.match(url, exceptUrlWhiteList) || matchReg.match(domain, exceptDomainWhiteList)) {
	blocked = false; outer = false;
} else {
	if(whiteList && moywhitelist!='true') {
		blocked = false; outer = false;
	} else {
		if(blockall=='true'){
			blocked = true; outer = true; status = '2';
		} else {

			if(matchReg.match(url, exceptUrlBlackList) || matchReg.match(domain, exceptDomainBlackList)) {
				blocked = true; outer = true; status = '2';
			} else {
				if(blackList && moyblacklist!='true') {
					blocked = true; outer = true; status = '2';
				}
			}
		}
	}
}	
	
links=location.href;	
	
}
if(blocked) {
if (outer){badWords=false;} else {badWords = matchWorld.match(title) +  matchWorld.match(pageDescription) + matchWorld.match(pageKeywords) + matchWorld.match(content); status = '5';}
	if(outer || (badWords && keywords!='true') || (badWords && moykeyword!='true'))	{
		var path = chrome.runtime.getURL("html/block.html");
		var tabURL = path + '?domain-block=' + encodeURIComponent(UTILS.toBase64(url)) + '&domain-status=' + status;
		var remoteTabURL = 'https://lidrekon.ru/block/block.php?domain-block=' + encodeURIComponent(UTILS.toBase64(url)) + '&domain-status=' + status + '&uid=' + UID;
		var urlblock='0';
		
		LIBRARY.ajax({url: 'https://lidrekon.ru/block/checkopentab.php', success: function(data) {
			if(data === 'true') {urlblock='1';document.location.replace(remoteTabURL);}
			else {urlblock='1';document.location.replace(tabURL);}	
		}});
		if (urlblock=='0'){document.location.replace(remoteTabURL);}
	} else {document.body.style.opacity = "100";}
} else {document.body.style.opacity = "100";
		document.body.classList.add('c-f');
}

}}

