$('#text1').html(Localization('optionsPage.text1') + $('#text1').html());
$('#text2').html(Localization('optionsPage.text2') + $('#text2').html());
$('#text3').html(Localization('optionsPage.text3') + $('#text3').html());
$('#text4').html(Localization('optionsPage.text4') + $('#text4').html());
$('#text5').html(Localization('optionsPage.text5') + $('#text5').html());
$('#text6').html(Localization('optionsPage.text6') + $('#text6').html());
$('#text7').html(Localization('optionsPage.text7') + $('#text7').html());
$('#text8').html(Localization('optionsPage.text8') + $('#text8').html());
$('#change-pass').html(Localization('optionsPage.text9') + $('#change-pass').html());
$('#text10').html(Localization('optionsPage.text10') + $('#text10').html());
$('#text11').html(Localization('optionsPage.text11') + $('#text11').html());
$('#text12').html(Localization('optionsPage.text12') + $('#text12').html());
$('#text13').html(Localization('optionsPage.text13') + $('#text13').html());
$('#text14').html(Localization('optionsPage.text14') + $('#text14').html());
$('#text15').html(Localization('optionsPage.text15') + $('#text15').html());
$('#text16').html(Localization('optionsPage.text16') + $('#text16').html());
$('#text17').html(Localization('optionsPage.text17') + $('#text17').html());
$('#text18').html(Localization('optionsPage.text18') + $('#text18').html());
$('#text19').html(Localization('optionsPage.text19') + $('#text19').html());
$('#text20').html(Localization('optionsPage.text20') + $('#text20').html());
$('#text21').html(Localization('optionsPage.text21') + $('#text21').html());
$('#text22').html(Localization('optionsPage.text22') + $('#text22').html());
$('#text23').html(Localization('optionsPage.text23') + $('#text23').html());
$('#text24').html(Localization('optionsPage.text24') + $('#text24').html());
$('#text25').html(Localization('optionsPage.text25') + $('#text25').html());
$('#text26').html(Localization('optionsPage.text26') + $('#text26').html());
$('#text27').html(Localization('optionsPage.text27') + $('#text27').html());
$('#text28').html(Localization('optionsPage.text28') + $('#text28').html());
$('#text29').html(Localization('optionsPage.text29') + $('#text29').html());
$('#text30').html(Localization('optionsPage.text30') + $('#text30').html());
$('#text31').html(Localization('optionsPage.text31') + $('#text31').html());
$('#text33').html(Localization('optionsPage.text33') + $('#text33').html());
$('#text34').html(Localization('optionsPage.text34') + $('#text34').html());
$('#text35').html(Localization('optionsPage.text35') + $('#text35').html());
$('#text36').html(Localization('optionsPage.text36') + $('#text36').html());
$('#text37').html(Localization('optionsPage.text37') + $('#text37').html());
$('#text38').html(Localization('optionsPage.text38') + $('#text38').html());
$('#text39').html(Localization('optionsPage.text39') + $('#text39').html());

var path = chrome.runtime.getURL("html/options.html");
chrome.history.deleteUrl({url: path});

if(LIBRARY.load('password')) {$('#modal').modal({show: true});}

getWhiteList();
getBlackList();
getkeyword();//
geturlwhitelistlist();
getdomenwhitelistlist();
geturlblacklistlist();
getdomenblacklistlist();
getkeywordslist();

$('#black-list').on('click', 'a.icon-delete', function(e) {
	e.preventDefault();
	var url = $(this).attr('data-url');

	UTILS.removeBlackList(url);
	getBlackList();
	return false;
});

$('#keyword-list').on('click', 'a.icon-delete', function(e) {//
	e.preventDefault();
	var url = $(this).attr('data-url');

	UTILS.removekeyword(url);
	getkeyword();
	return false;
});


$('#white-list').on('click', 'a.icon-delete', function(e) {
	e.preventDefault();
	var url = $(this).attr('data-url');

	UTILS.removeWhiteList(url);
	getWhiteList();
	return false;
});

function getWhiteList() {
	var ul = $('#white-list');
	var whiteList = UTILS.getWhiteList();
	var list = '';
	var num = whiteList.length;

var table = document.getElementById('white-list');
table.innerHTML="";
for(var i = 0; i < num; i++) {
var tr = document.createElement('tr');
var td = document.createElement('td');
var td1 = document.createElement('td');
var a = document.createElement('a');
td.innerHTML = whiteList[i];
tr.appendChild(td);
td1.style.width = '30px';
a.title='Delete';
a.href=' ';
a.setAttribute('data-url', whiteList[i]);
a.className='icon-delete';
a.innerHTML='<i title="Delete" class="glyphicon glyphicon-remove"></i>';
td1.appendChild(a);
tr.appendChild(td1);
table.appendChild(tr);
}
var input = LIBRARY.load('white-load');
$('#input-white-load').val(input);
}


if(LIBRARY.load('password')) {$('#oldpass').prop('disabled', false);} else {$('#oldpass').prop('disabled', true);}

$('#change-pass').bind('click', function() {
	var oldpass = window.btoa(unescape(encodeURIComponent($('#oldpass').val()+LIBRARY.load('UID'))));
	
if (($('#pass1').val()=='') && ($('#pass2').val()=='')){var pass1='', pass2='';}else{
	var pass1 = window.btoa(unescape(encodeURIComponent($('#pass1').val()+LIBRARY.load('UID'))));
	var pass2 = window.btoa(unescape(encodeURIComponent($('#pass2').val()+LIBRARY.load('UID'))));
}
	
if(LIBRARY.load('password')) {
var verif = (LIBRARY.load('password') == oldpass);
	if(verif && (pass1 == pass2)) {
		LIBRARY.save('password', pass1);
		alert(Localization('optionsPage.js.text1'));
		window.location.reload();
	}else {
		alert(Localization('optionsPage.js.text2'));
	}
} else {
	if (!($('#pass1').val()=='') && (pass1 == pass2)) {
		LIBRARY.save('password', pass1);
		alert(Localization('optionsPage.js.text1'));
		window.location.reload();
	}else {
		alert(Localization('optionsPage.js.text2'));
	}
}	
if(LIBRARY.load('password')) {$('#oldpass').prop('disabled', false);} else {$('#oldpass').prop('disabled', true);}
	return false;
});

$('#hidaIcon').bind('change', function() {
	var el = $(this)
	var status = el.prop('checked');

	if(status) {
		UTILS.hideIcon();
	} else {
		UTILS.showIcon();
	}
});

//1111111111111111111111111111111
$('#onoff').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hideonoff();
} else {UTILS.showonoff();}
});

$('#update').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hideupdate();
} else {UTILS.showupdate();}
});

$('#blockall').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hideblockall();
} else {UTILS.showblockall();}
});

$('#urlwhitelist').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hideurlwhitelist();
} else {UTILS.showurlwhitelist();}
});

$('#moywhitelist').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hidemoywhitelist();
} else {UTILS.showmoywhitelist();}
});

$('#moyblacklist').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hidemoyblacklist();
} else {UTILS.showmoyblacklist();}
});

$('#moykeyword').bind('change', function() {//
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hidemoykeyword();
} else {UTILS.showmoykeyword();}
});


$('#domainwhitelist').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hidedomainwhitelist();
} else {UTILS.showdomainwhitelist();}
});

$('#urlblacklist').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hideurlblacklist();
} else {UTILS.showurlblacklist();}
});

$('#domainblacklist').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hidedomainblacklist();
} else {UTILS.showdomainblacklist();}
});

$('#keywords').bind('change', function() {
var el = $(this)
var status = el.prop('checked');
if(status) {
UTILS.hidekeywords();
} else {UTILS.showkeywords();}
});

$('#onoff').prop('checked', UTILS.getonoff() === 'true' ? true : false);
$('#update').prop('checked', UTILS.getupdate() === 'true' ? true : false);
$('#hidaIcon').prop('checked', UTILS.getViewbilityIcon() === 'true' ? true : false);
$('#blockall').prop('checked', UTILS.getblockall() === 'true' ? true : false);

$('#urlwhitelist').prop('checked', UTILS.geturlwhitelist() === 'false' ? true : false);
$('#domainwhitelist').prop('checked', UTILS.getdomainwhitelist() === 'false' ? true : false);
$('#urlblacklist').prop('checked', UTILS.geturlblacklist() === 'false' ? true : false);
$('#domainblacklist').prop('checked', UTILS.getdomainblacklist() === 'false' ? true : false);
$('#keywords').prop('checked', UTILS.getkeywords() === 'false' ? true : false);
$('#moywhitelist').prop('checked', UTILS.getmoywhitelist() === 'false' ? true : false);
$('#moyblacklist').prop('checked', UTILS.getmoyblacklist() === 'false' ? true : false);
$('#moykeyword').prop('checked', UTILS.getmoykeyword() === 'false' ? true : false);
//111111111111111111


function getBlackList() {
	var ul = $('#black-list');
	var blackList = UTILS.getBlackList();
	var list = '';
	var num = blackList.length;
	
	var table = document.getElementById('black-list');
table.innerHTML="";
	for(var i = 0; i < num; i++) {
	
var tr = document.createElement('tr');
var td = document.createElement('td');
var td1 = document.createElement('td');
var a = document.createElement('a');
td.innerHTML = blackList[i];
tr.appendChild(td);

td1.style.width = '30px';

a.title='Delete';
a.href=' ';
a.setAttribute('data-url', blackList[i]);
a.className='icon-delete';
a.innerHTML='<i title="Delete" class="glyphicon glyphicon-remove"></i>';
td1.appendChild(a);


tr.appendChild(td1);
table.appendChild(tr);
}
var input = LIBRARY.load('black-load');
$('#input-black-load').val(input);
}

function getkeyword() {//
	var ul = $('#keyword-list');
	var keyword = UTILS.getkeyword();
	var list = '';
	var num = keyword.length;
	
	var table = document.getElementById('keyword-list');
table.innerHTML="";
	for(var i = 0; i < num; i++) {
	
var tr = document.createElement('tr');
var td = document.createElement('td');
var td1 = document.createElement('td');
var a = document.createElement('a');
td.innerHTML = keyword[i];
tr.appendChild(td);

td1.style.width = '30px';

a.title='Delete';
a.href=' ';
a.setAttribute('data-url', keyword[i]);
a.className='icon-delete';
a.innerHTML='<i title="Delete" class="glyphicon glyphicon-remove"></i>';
td1.appendChild(a);


tr.appendChild(td1);
table.appendChild(tr);
}
var input = LIBRARY.load('keyword-load');
$('#input-keyword-load').val(input);
}




function geturlwhitelistlist() {
	var ul = $('#urlwhitelistlist');
	var urlwhitelistlist = UTILS.geturlwhitelistlist();
	var list = '';
	var num = urlwhitelistlist.length;
	var table = document.getElementById('urlwhitelistlist');
	for(var i = 0; i < num; i++) {
var tr = document.createElement('tr');
var td = document.createElement('td');
td.innerHTML = urlwhitelistlist[i];
tr.appendChild(td);
table.appendChild(tr);
	}
}

function getdomenwhitelistlist() {
	var ul = $('#domenwhitelistlist');
	var domenwhitelistlist = UTILS.getdomenwhitelistlist();
	var list = '';
	var num = domenwhitelistlist.length;
	var table = document.getElementById('domenwhitelistlist');
	for(var i = 0; i < num; i++) {
var tr = document.createElement('tr');
var td = document.createElement('td');
td.innerHTML = domenwhitelistlist[i];
tr.appendChild(td);
table.appendChild(tr);
	}
}

function geturlblacklistlist() {
	var ul = $('#urlblacklistlist');
	var urlblacklistlist = UTILS.geturlblacklistlist();
	var list = '';
	var num = urlblacklistlist.length;
	var table = document.getElementById('urlblacklistlist');
	for(var i = 0; i < num; i++) {
var tr = document.createElement('tr');
var td = document.createElement('td');
td.innerHTML = urlblacklistlist[i];
tr.appendChild(td);
table.appendChild(tr);		
	}
}

function getdomenblacklistlist() {
	var ul = $('#domenblacklistlist');
	var domenblacklistlist = UTILS.getdomenblacklistlist();
	var list = '';
	var num = domenblacklistlist.length;
	var table = document.getElementById('domenblacklistlist');
	for(var i = 0; i < num; i++) {
var tr = document.createElement('tr');
var td = document.createElement('td');
td.innerHTML = domenblacklistlist[i];
tr.appendChild(td);
table.appendChild(tr);
	}
}

function getkeywordslist() {
	var ul = $('#keywordslist');
	var keywordslist = UTILS.getkeywordslist();
	var list = '';
	var num = keywordslist.length;
	var table = document.getElementById('keywordslist');

for(var i = 0; i < num; i++) {
var tr = document.createElement('tr');
var td = document.createElement('td');
td.innerHTML = keywordslist[i];
tr.appendChild(td);
table.appendChild(tr);
}
}



$('#button-white-list').bind('click', function() {
var input = $('#input-white-list').val();
var arr = input.replace(/\s/g, '');
//var regex = /^(ftp|http|https):\/\/+?/;
//if(regex .test(arr)) {
if (input!=''){
UTILS.removeBlackList(arr);
UTILS.addWhiteList(arr);
}//}
$('#input-white-list').val(null);
return getWhiteList();
})

$('#button-black-list').bind('click', function() {
var input = $('#input-black-list').val();
var arr = input.replace(/\s/g, '');
//var regex = /^(ftp|http|https):\/\/+?/;

//if(regex .test(arr)) {
if (input!=''){
UTILS.removeWhiteList(arr);
UTILS.addBlackList(arr);
}//}
$('#input-black-list').val(null);
return getBlackList();
})


$('#button-keyword-list').bind('click', function() {////////////////////////////////
var input = $('#input-keyword-list').val();
var arr = input.replace(/\s/g, '');
//var regex = /^(ftp|http|https):\/\/+?/;
//if(regex .test(arr)) {
if (input!=''){UTILS.addkeyword(arr);}
 // }
$('#input-keyword-list').val(null);
return getkeyword();
})



$('#load-white-list').bind('change', function() {
var selectedFile = document.getElementById('load-white-list').files[0];
var reader = new FileReader ();

reader.onload = function (e) {
var FileContent = e.target.result;
parseContent(FileContent);
$('#load-white-list').val(null);
};
reader.readAsText(selectedFile);
});

function parseContent(content) {
var input = '';
LIBRARY.save('whiteList', input);

var arr = content.split('\n');
for (var i = 0; i <= arr.length-1; i++) {
var input = arr[i].replace(/\s/g, '');
//var regex = /^(ftp|http|https):\/\/+?/;

//if(regex.test(input)) {
if (input!=''){
UTILS.removeBlackList(input);
UTILS.addWhiteList(input);}
}
getWhiteList();
getBlackList();
}

$('#load-black-list').bind('change', function() {
var selectedFile = document.getElementById('load-black-list').files[0];
var reader = new FileReader ();
reader.onload = function (e) {
var FileContent = e.target.result;
parseContent2(FileContent);
$('#load-black-list').val(null);
};
reader.readAsText(selectedFile);
});

function parseContent2(content) {
var input = '';
LIBRARY.save('blackList', input);

var arr = content.split('\n');
for (var i = 0; i <= arr.length-1; i++) {
var input = arr[i].replace(/\s/g, '');
//var regex = /^(ftp|http|https):\/\/+?/;

//if(regex.test(input)) {
if (input!=''){
UTILS.removeWhiteList(input);
UTILS.addBlackList(input);}
}
getBlackList();
getWhiteList();
}

$('#load-keyword-list').bind('change', function() {//////////////
var selectedFile = document.getElementById('load-keyword-list').files[0];
var reader = new FileReader ();
reader.onload = function (e) {
var FileContent = e.target.result;
parseContent3(FileContent);
$('#load-keyword-list').val(null);
};
reader.readAsText(selectedFile);
});

function parseContent3(content) {////////////
var input = '';
LIBRARY.save('keyword', input);

var arr = content.split('\n');
for (var i = 0; i <= arr.length-1; i++) {
var input = arr[i];
//var regex = /^(ftp|http|https):\/\/+?/;
// if(regex .test(input)) {
if (input!=''){UTILS.addkeyword(input);}
//}
}
getkeyword();
}

function saveText(filename, text) {
var tempElem = document.createElement('a');
tempElem.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
tempElem.setAttribute('download', filename);
tempElem.click();
}

$('#save-white-list').bind('click', function() {
var whitelist = UTILS.getWhiteList();
var list = '';
var num = whitelist.length;
for(var i = 0; i < num; i++) {list += '' + whitelist[i] + '\n'}

var myStrText=JSON.stringify(list);
saveText("whiteList.txt", list);
});

$('#save-black-list').bind('click', function() {
var blacklist = UTILS.getBlackList();
var list = '';
var num = blacklist.length;
for(var i = 0; i < num; i++) {list += '' + blacklist[i] + '\n'}

var myStrText=JSON.stringify(list);
saveText("blacklist.txt", list);
});

$('#save-keyword-list').bind('click', function() {//////////
var keyword = UTILS.getkeyword();
var list = '';
var num = keyword.length;
for(var i = 0; i < num; i++) {list += '' + keyword[i] + '\n'}

var myStrText=JSON.stringify(list);
saveText("keyword.txt", list);
});

function readTextFile(file)
{
    var rawFile = new XMLHttpRequest();
    rawFile.open("GET", file, false);
    rawFile.onreadystatechange = function ()
    {
        if(rawFile.readyState === 4)
        {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
                var allText = rawFile.responseText;
                alert(allText);
            }
        }
    }
    rawFile.send(null);
}

function Localization(key) {
	var newKey = key.replace(/\./img, '_');

	return chrome.i18n.getMessage(newKey);
}

$('#button-white-load').bind('click', function() {
var input = $('#input-white-load').val();
LIBRARY.save('white-load', input);
$('#input-white-load').val(input);
whiteload ();
});

$('#button-black-load').bind('click', function() {
var input = $('#input-black-load').val();
LIBRARY.save('black-load', input);
$('#input-black-load').val(input);
blackload ();
});


$('#button-keyword-load').bind('click', function() {///////////
var input = $('#input-keyword-load').val();
LIBRARY.save('keyword-load', input);
$('#input-keyword-load').val(input);
keywordload ();
});


$('#button-white-clear').bind('click', function() {
var input = '';
LIBRARY.save('white-load', input);
getWhiteList();
});

$('#button-black-clear').bind('click', function() {
var input = '';
LIBRARY.save('black-load', input);
getBlackList();
});

$('#button-keyword-clear').bind('click', function() {////////////
var input = '';
LIBRARY.save('keyword-load', input);
getkeyword();
});


$('#delete-white-list').bind('click', function() {
var input = '';
LIBRARY.save('whiteList', input);
getWhiteList();
});

$('#delete-black-list').bind('click', function() {
var input = '';
LIBRARY.save('blackList', input);
getBlackList();
});

$('#delete-keyword-list').bind('click', function() {//////
var input = '';
LIBRARY.save('keyword', input);
getkeyword();
});

function whiteload () {
var input = LIBRARY.load('white-load');
	var request = new XMLHttpRequest();
    request.open('GET', input, true);
    request.send(null);
    request.onreadystatechange = function () {
        if (request.readyState === 4 && request.status === 200) {
            var type = request.getResponseHeader('Content-Type');
            if (type.indexOf("text") !== 1) {
				parseContent(request.responseText);
                return request.responseText;
            }
        }
    }
}

function blackload () {
var input = LIBRARY.load('black-load');
	var request = new XMLHttpRequest();
    request.open('GET', input, true);
    request.send(null);
    request.onreadystatechange = function () {
        if (request.readyState === 4 && request.status === 200) {
            var type = request.getResponseHeader('Content-Type');
            if (type.indexOf("text") !== 1) {
				parseContent2(request.responseText);
                return request.responseText;
            }
        }
    }
}

function keywordload () {
var input = LIBRARY.load('keyword-load');
	var request = new XMLHttpRequest();
    request.open('GET', input, true);
    request.send(null);
    request.onreadystatechange = function () {
        if (request.readyState === 4 && request.status === 200) {
            var type = request.getResponseHeader('Content-Type');
            if (type.indexOf("text") !== 1) {
				parseContent3(request.responseText);
                return request.responseText;
            }
        }
    }
}


//////////
$('#text1').html(Localization('blockPage.text1') + $('#text1').html());
$('#text2').html(Localization('blockPage.text2') + $('#text2').html());

$("#pwd-submit").bind('click', function() {
var pass = $('#input-pass').val();
checkPassword(pass);
});

$("#pwd-close").bind('click', function() {
window.open('','_parent',''); 
window.close()
});

function checkPassword(pass) {
	if(LIBRARY.load('password') === window.btoa(unescape(encodeURIComponent(pass+LIBRARY.load('UID'))))) {

	} else {
		document.body.style.opacity = "0";
		alert(Localization('actionPopup.js.log8'));
		window.open('','_parent',''); 
		window.location.reload();

	}
}
//////////
$(document).ready(function() {
$("html").contextmenu(function(){ 
return false; 
});
});